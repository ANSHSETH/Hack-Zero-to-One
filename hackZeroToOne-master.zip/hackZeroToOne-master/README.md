# hackZeroToOne
Agenda:
The agenda of our Project is centric towards Entertainment Innovation. In this we are working towards building a Portal where the students of educational institutions or working professionals of a firm can find like or alike minded companions to spend their free time with. Our approach is focused towards linking people so the they can spend their time in a more useful and meaningful manner.
Rather than wasting time, our agenda is to propagate masses towards utilizing time in a more productive way. This helps in improving the thought process and also widens up the area of exploration. 
In this people can also finds events of their interest and can also share their idea by publishing their own event for mass participation.
The interests can include outdoor games, computer science, poetry, politics , photography etc.


Goals:
1. Building Front End and Back End : #Creating a "Home page" or a Welcome screen
                                     #Creating a "Login" form for already registered people 
                                     #Creating a "Sign-up" form for new users
                                     #Creating a "Find Companion" page where an individual can find others
                                     #To create a page where individuals can "find events" of their interest
                                     #Creating a page where an individual or  group of individuals can publish an event of theirs for                                            masses to join
                                     #We will create a chap page to connect the people of similar interests after taking permissions from                                       each other. So that they can decide a place to meet or for transfer of information.
                                   
